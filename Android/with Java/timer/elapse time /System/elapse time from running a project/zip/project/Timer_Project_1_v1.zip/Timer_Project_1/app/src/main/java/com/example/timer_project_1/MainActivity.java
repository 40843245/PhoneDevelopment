package com.example.timer_project_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{


    //runs without a timer by reposting this handler at the end of the runnable

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView timerTextView;
        long startTime;
        Handler timerHandler = new Handler();


        Runnable timerRunnable;

        startTime=System.currentTimeMillis() ;

        timerTextView=(TextView) findViewById(R.id.TextView_1);

        timerTextView.setTextSize(25f);


        timerRunnable= new Runnable()
        {

            @Override
            public void run()
            {

                long millis = System.currentTimeMillis() - startTime;
                int seconds = (int) (millis / 1000);
                int minutes = seconds / 60;
                seconds = seconds % 60;

                timerTextView.setText("");
                timerTextView.append("The project running elapse time\n which determined by \nthe System.currentTimeMillis():");
                timerTextView.append("\n");
                timerTextView.append(String.format("%d:%02d", minutes, seconds));

                timerHandler.postDelayed(this, 500);
            }
        };

        timerHandler.postDelayed(timerRunnable,500);
    }


}