package com.example.fileuploader_image_3;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity
{
    TextView textView_1;
    TextView textView_2;
    TextView textView_3;
    TextView textView_4;

    Intent intent;
    ActivityResultLauncher<Intent> activityResultLauncher;

    int REQUEST_CODE = 10;




    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView_1 = findViewById(R.id.TextView_1);
        textView_2 = findViewById(R.id.TextView_2);
        textView_3 = findViewById(R.id.TextView_3);
        textView_4 = findViewById(R.id.TextView_4);

        textView_1.setText("");
        textView_2.setText("");
        textView_3.setText("");
        textView_4.setText("");

        intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/jpg");
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>()
                {
                    @Override
                    public void onActivityResult(ActivityResult result)
                    {
                        if (result.getResultCode() == Activity.RESULT_OK)
                        {
                            Intent data = result.getData();
                            Uri dataUri = data.getData();

                            ImageView imageView = findViewById(R.id.ImageView_1);
                            imageView.setImageURI(dataUri);

                            textView_2.append("uri:"+dataUri.toString()+"\n");
                            textView_2.append("uri.getPath():"+dataUri.getPath()+"\n");
                        }
                    }
                });
        activityResultLauncher.launch(intent);


    }
}