package com.example.alarmmanager_1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationChannelCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import android.R.drawable;

public class MainActivity extends AppCompatActivity
{
    private static final String CHANNEL_ID = NotificationManagerCompat.EXTRA_USE_SIDE_CHANNEL;
    TextView textView_1;
    TextView textView_2;
    TextView textView_3;
    TextView textView_4;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView_1 = findViewById(R.id.TextView_1);
        textView_2 = findViewById(R.id.TextView_2);
        textView_3 = findViewById(R.id.TextView_3);
        textView_4 = findViewById(R.id.TextView_4);

        textView_1.setText("");
        textView_2.setText("");
        textView_3.setText("");
        textView_4.setText("");


        try
        {
            NotificationChannel notificationChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Followers",
                    NotificationManager.IMPORTANCE_HIGH
            );
            notificationChannel.setLightColor(Color.GREEN);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_background)
                    .setContentTitle("Title 1")
                    .setContentText("Content 1")
                    .setChannelId(CHANNEL_ID)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            Notification notification = builder.build();
            NotificationManager notificationManager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);

            textView_2.setText("");
            textView_2.append(notification.toString()+"\n");

            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            {
                textView_1.setText("");
                textView_1.append("ERROR!!! POST_NOTIFICATIONS permission NOT granted successfully."+"\n");

                ActivityCompat.requestPermissions(this,
                        new String[]
                                {
                                        android.Manifest.permission.POST_NOTIFICATIONS
                                },
                        0
                );
            }
            textView_3.setText("");
            textView_3.append(String.valueOf(notificationManager.areNotificationsEnabled()));

            notificationManager.notify(
                    "123",NotificationManagerCompat.IMPORTANCE_HIGH,
                    notification
            );
            textView_1.setText("");
            textView_1.append("Notified\n");
        }
        catch (Exception exception)
        {
            textView_1.setText("");
            textView_1.append(exception.toString());
            textView_1.append("\n");
        }
    }
}