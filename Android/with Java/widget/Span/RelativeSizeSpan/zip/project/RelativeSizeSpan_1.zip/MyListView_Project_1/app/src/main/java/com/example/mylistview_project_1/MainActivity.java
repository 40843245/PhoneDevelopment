package com.example.mylistview_project_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import android.R.layout;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    LinearLayout LinearLayout_listView;
    ArrayAdapter<Spannable> arrayAdapter;

    ListView ListView_1;
    ArrayList<Spannable> spannable_list;
    Spannable spannable_array[];

    float proportion;

    String  myStringArray []={ "Algorithms", "Data Structures",
            "Languages", "Interview Corner",
            "GATE", "ISRO CS",
            "UGC NET CS", "CS Subjects",
            "Web Technologies" };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView_1=(ListView)findViewById(R.id.ListView_1);

        spannable_list=new ArrayList<Spannable>();

        proportion=2f;

        spannable_list.clear();


        for(int i=0;i<myStringArray.length;i++)
        {
            Spannable spannable_temp;
            spannable_temp=new SpannableString(myStringArray[i]);

            spannable_temp.setSpan(new RelativeSizeSpan(proportion)
                    ,0
                    ,spannable_temp.length()
                    ,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannable_list.add(spannable_temp);
        }


        spannable_array=new Spannable[spannable_list.size()];


        for(int i=0;i<spannable_list.size();i++)
        {
            spannable_array[i]=spannable_list.get(i);
        }
        arrayAdapter=new ArrayAdapter<Spannable>(this,
                android.R.layout.simple_spinner_item,
                spannable_array
        );

        ListView_1.setAdapter(arrayAdapter);



        ListView_1.setSelection(0);


    }
}