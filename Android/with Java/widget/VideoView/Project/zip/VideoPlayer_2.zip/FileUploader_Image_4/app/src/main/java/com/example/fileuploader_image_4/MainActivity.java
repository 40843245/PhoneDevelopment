package com.example.fileuploader_image_4;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    TextView textView_1;
    TextView textView_2;
    TextView textView_3;
    TextView textView_4;

    Intent intent;
    ActivityResultLauncher<Intent> activityResultLauncher;

    int REQUEST_CODE = 10;
    VideoView videoView_1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView_1 = findViewById(R.id.TextView_1);
        textView_2 = findViewById(R.id.TextView_2);
        textView_3 = findViewById(R.id.TextView_3);
        textView_4 = findViewById(R.id.TextView_4);

        textView_1.setText("");
        textView_2.setText("");
        textView_3.setText("");
        textView_4.setText("");

        videoView_1 = findViewById(R.id.VideoView_1);

        textView_1.append("onCreate();\n");
        videoView_1.setVideoPath("");
        videoView_1.setOnErrorListener(new MediaPlayer.OnErrorListener()
        {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra)
            {
                textView_1.setText("");
                textView_1.append("ERROR!!! Can NOT play the media player.\n");
                return false;
            }
        });

        videoView_1.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
        {
            @Override
            public void onCompletion(MediaPlayer mp)
            {
                textView_1.setText("");
                textView_1.append("Success!!! Complete to play the media player.\n");
                return;
            }
        });
        intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("video/*");
        //intent.putExtra(Intent.EXTRA_EMAIL, true);

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>()
                {
                    @Override
                    public void onActivityResult(ActivityResult result)
                    {
                        if (result.getResultCode() == Activity.RESULT_OK)
                        {
                            Intent data = result.getData();
                            Uri dataUri = data.getData();

                            videoView_1.setVideoURI(dataUri);

                            textView_2.append("uri:"+dataUri.toString()+"\n");
                            textView_2.append("uri.getPath():"+dataUri.getPath()+"\n");
                            videoView_1.start();
                        }
                    }
                });
        activityResultLauncher.launch(intent);
    }
}