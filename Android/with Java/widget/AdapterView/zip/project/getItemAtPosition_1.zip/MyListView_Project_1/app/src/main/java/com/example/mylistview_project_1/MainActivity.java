package com.example.mylistview_project_1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.util.SparseBooleanArray;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import android.R.layout;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    LinearLayout LinearLayout_listView;
    ArrayAdapter<Spannable> arrayAdapter;

    ListView ListView_1;
    ArrayList<Spannable> spannable_list;
    Spannable spannable_array[];

    float proportion;

    int selectedIndex;

    TextView textView1;

    String  myStringArray []={ "Algorithms", "Data Structures",
            "Languages", "Interview Corner",
            "GATE", "ISRO CS",
            "UGC NET CS", "CS Subjects",
            "Web Technologies" };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView_1=(ListView)findViewById(R.id.ListView_1);

        spannable_list=new ArrayList<Spannable>();

        proportion=2f;

        textView1=(TextView) findViewById(R.id.TextView_1);

        spannable_list.clear();


        for(int i=0;i<myStringArray.length;i++)
        {
            Spannable spannable_temp;
            spannable_temp=new SpannableString(myStringArray[i]);

            spannable_temp.setSpan(new RelativeSizeSpan(proportion)
                    ,0
                    ,spannable_temp.length()
                    ,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannable_list.add(spannable_temp);
        }


        spannable_array=new Spannable[spannable_list.size()];


        for(int i=0;i<spannable_list.size();i++)
        {
            spannable_array[i]=spannable_list.get(i);
        }
        arrayAdapter=new ArrayAdapter<Spannable>(this,
                android.R.layout.simple_spinner_item,
                spannable_array
        );

        ListView_1.setAdapter(arrayAdapter);

        ListView_1.setSelection(0);


        // the event callback function will be called once the item was selected.
        ListView_1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            // override the event callback function
            @Override
            public void onItemClick(
                    AdapterView<?> adapterView,
                    View view,
                    int i, // index of current selected item
                    long l)
            {
                // backup the index.
                selectedIndex=i;

                // clear the text.
                textView1.setText("");
                textView1.append("\n");

                textView1.append(Integer.toString(selectedIndex));
                textView1.append("\n");

                textView1.append(ListView_1.getItemAtPosition(selectedIndex).toString());

                // Cause bugs.
                // selectedIndex=ListView_1.getCheckedItemPosition();

                for (int j = 0; j < ListView_1.getChildCount(); j++)
                {
                    if(j == selectedIndex)
                    {
                        ListView_1.getChildAt(j).setBackgroundColor(Color.BLUE);
                    }else
                    {
                        ListView_1.getChildAt(j).setBackgroundColor(Color.TRANSPARENT);
                    }
                }

            }
        });
    }
}