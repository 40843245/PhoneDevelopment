package com.example.list_project_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.Gravity;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    ArrayList<EditText> editText_list;
    ArrayList<String> string_list;

    EditText currEditText_1;
    EditText currEditText_2;
    LinearLayout linearLayout1;
    LinearLayout linearLayout_root;
    TextView textView1;
    TextView textView2;
    Spannable spannable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout1=(LinearLayout) findViewById(R.id.LinearLayout_1);
        linearLayout_root=(LinearLayout) findViewById(R.id.LinearLayout_root);

        textView1=new TextView(this);
        string_list=new ArrayList<String>();

        editText_list=new ArrayList<EditText>();

        linearLayout_root.setGravity(
                  Gravity.BOTTOM
                 | Gravity.LEFT
        );

        string_list.clear();
        editText_list.clear();

        string_list.add("Elem1");
        string_list.add("Elem2");
        string_list.add("Elem3");
        string_list.add("Elem4");

        textView1.setText("");

        for(int i=0;i<string_list.size();i++)
        {
            currEditText_1=new EditText(this);
            currEditText_1.setText(string_list.get(i));
            currEditText_1.setCursorVisible(true);

            currEditText_1.setTextSize(20f);
            editText_list.add(currEditText_1);
            linearLayout1.addView(currEditText_1);
        }



        textView1.setText("");

        textView1.append("textView1");
        linearLayout_root.addView(textView1);




    }
}