package com.example.framelayout_project_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Spannable;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    FrameLayout mainFrameLayout1;
    TextView mainTextView;
    Button button1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_2);
        mainFrameLayout1=(FrameLayout) findViewById(R.id.FrameLayout_1);

        mainTextView=new TextView(this);
        mainTextView.setText("Shoot");
        mainTextView.setTextSize(50f);
        mainFrameLayout1.addView(mainTextView);


        button1=new Button(this);
        button1.setText("Button1");
        button1.setTextSize(25f);

        mainFrameLayout1.addView(button1);


    }
}